import React, { useState } from 'react';
import { Link, Outlet, useLocation } from 'react-router-dom';
import { ShoppingBag, Globe, MapPin, Search, Menu, X, ShieldAlert } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export function Layout() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchMobileOpen, setIsSearchMobileOpen] = useState(false);
  const location = useLocation();

  const closeMenu = () => {
    setIsMobileMenuOpen(false);
    setIsSearchMobileOpen(false);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">

      {/* Main Header */}
      <header className="bg-white sticky top-0 z-40 border-b border-slate-200 shadow-sm relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 py-3 min-h-[60px] flex flex-col justify-center">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-8">
              {/* Logo */}
              <Link to="/" className="flex items-center gap-2 group" onClick={closeMenu}>
                <img 
                  src="/logo.png" 
                  alt="" 
                  className="h-8 w-8 object-contain"
                  onError={(e) => { e.currentTarget.style.display = 'none'; }}
                />
                <span className="text-2xl font-bold tracking-tight text-blue-700">Abbasi<span className="text-slate-900">Mart</span></span>
              </Link>

              {/* Desktop Nav */}
              <nav className="hidden md:flex gap-6 text-sm font-medium text-slate-600">
                <Link
                  to="/"
                  className={`transition-colors hover:text-blue-600 ${
                    location.pathname === '/' ? 'text-blue-600' : ''
                  }`}
                >
                  Home
                </Link>
                <Link
                  to="/pakistan-deals"
                  className={`transition-colors hover:text-blue-600 ${
                    location.pathname === '/pakistan-deals' ? 'text-blue-600' : ''
                  }`}
                >
                  Pakistan Deals
                </Link>
                <Link
                  to="/global-deals"
                  className={`transition-colors hover:text-blue-600 ${
                    location.pathname === '/global-deals' ? 'text-blue-600' : ''
                  }`}
                >
                  Global Deals
                </Link>
              </nav>
            </div>

            <div className="flex-1 max-w-md mx-8 hidden lg:block">
              <div className="relative">
                <input type="text" placeholder="Search smart products..." className="w-full bg-slate-100 border-none rounded-full py-2 px-10 text-sm focus:ring-2 focus:ring-blue-500 outline-none" />
                <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              </div>
            </div>

            {/* Admin Link & Mobile Toggle */}
            <div className="flex items-center gap-2 md:gap-4">
              <button 
                className="lg:hidden p-2 text-slate-600 hover:text-slate-900"
                onClick={() => setIsSearchMobileOpen(true)}
              >
                <Search className="w-5 h-5" />
              </button>
              <Link
                to="/admin"
                className="hidden md:flex bg-slate-900 text-white text-xs font-bold px-4 py-2 rounded-lg transition-colors hover:bg-slate-800"
              >
                ADMIN PANEL
              </Link>
              <button
                className="md:hidden p-2 text-slate-600 hover:text-slate-900"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              >
                {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
          
          {/* Mobile Search Overlay */}
          <AnimatePresence>
            {isSearchMobileOpen && (
              <motion.div
                initial={{ x: '100%' }}
                animate={{ x: 0 }}
                exit={{ x: '100%' }}
                transition={{ type: "spring", bounce: 0, duration: 0.3 }}
                className="absolute inset-0 bg-white z-50 flex items-center px-4 sm:px-6 shadow-sm"
              >
                <Search className="w-5 h-5 text-slate-400 flex-shrink-0" />
                <input 
                  type="text" 
                  autoFocus
                  placeholder="Search smart products..." 
                  className="flex-1 bg-transparent border-none py-2 px-4 focus:ring-0 outline-none text-base w-full min-w-0"
                />
                <button 
                  className="p-2 text-slate-600 hover:text-slate-900 flex-shrink-0" 
                  onClick={() => setIsSearchMobileOpen(false)}
                >
                  <X className="w-6 h-6" />
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Mobile Nav Menu */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="md:hidden border-t border-slate-100 overflow-hidden bg-white"
            >
              <div className="px-4 pt-2 pb-6 space-y-1">
                <Link
                  to="/"
                  onClick={closeMenu}
                  className="block px-3 py-3 rounded-md text-base font-medium text-slate-900 hover:bg-slate-50"
                >
                  Home
                </Link>
                <Link
                  to="/pakistan-deals"
                  onClick={closeMenu}
                  className="block px-3 py-3 rounded-md text-base font-medium text-slate-900 hover:bg-slate-50"
                >
                  Pakistan Deals
                </Link>
                <Link
                  to="/global-deals"
                  onClick={closeMenu}
                  className="block px-3 py-3 rounded-md text-base font-medium text-slate-900 hover:bg-slate-50"
                >
                  Global Deals
                </Link>
                <div className="pt-4 mt-2 border-t border-slate-100">
                  <Link
                    to="/admin"
                    onClick={closeMenu}
                    className="flex items-center gap-2 px-3 py-2 rounded-md text-base font-medium text-slate-500 hover:bg-slate-50 hover:text-slate-900"
                  >
                    <ShieldAlert className="w-4 h-4" />
                    Admin Dashboard
                  </Link>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Main Content Area */}
      <main className="flex-grow w-full flex flex-col">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 mt-auto">
        <div className="max-w-7xl mx-auto px-6 py-4 flex flex-col md:flex-row items-center justify-center text-[11px] text-slate-500 gap-4 md:gap-0">
          <div className="flex flex-wrap justify-center gap-6 uppercase tracking-widest font-bold items-center">
            <a href="#" className="hover:text-blue-600">About</a>
            <Link to="/privacy-policy" className="hover:text-blue-600">Privacy Policy</Link>
            <Link to="/disclaimer" className="hover:text-blue-600">Affiliate Disclaimer</Link>
            <a href="mailto:abbasimart011@gmail.com" className="hover:text-blue-600 flex items-center gap-1">Contact: abbasimart011@gmail.com</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
