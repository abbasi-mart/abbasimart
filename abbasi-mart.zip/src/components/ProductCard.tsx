import React from 'react';
import { Product } from '../types';
import { Star, TrendingUp } from 'lucide-react';
import { motion } from 'motion/react';

interface ProductCardProps {
  key?: React.Key;
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      className="group flex flex-col bg-white border border-slate-200 rounded-3xl p-4 shadow-sm hover:shadow-lg transition-all duration-300"
    >
      <div className="flex items-center justify-between mb-3 px-1">
        <span className="bg-slate-100 text-slate-800 text-xs font-bold px-2.5 py-1 rounded-lg border border-slate-200 flex items-center gap-1.5">
           {product.category === 'pakistan' ? 'Pakistan' : 'Global'}
        </span>
        <div className="flex gap-1.5">
          {product.featured && <Star className="w-4 h-4 text-blue-600" fill="currentColor" />}
          {product.trending && <TrendingUp className="w-4 h-4 text-orange-500" />}
        </div>
      </div>

      {/* Image Container */}
      <div className="relative aspect-video rounded-2xl mb-4 overflow-hidden bg-slate-100 flex items-center justify-center">
        <img
          src={product.imageUrl}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
      </div>

      {/* Content */}
      <div className="flex flex-col flex-grow px-1">
        <h4 className="font-bold text-slate-900 text-lg leading-tight mb-2 line-clamp-2" title={product.name}>
          {product.name}
        </h4>
        
        <p className="text-slate-500 text-xs mb-4 line-clamp-2">
          {product.description}
        </p>
        
        <div className="mt-auto flex items-center justify-between">
          <span className="font-black text-xl text-slate-900">
            {product.price}
          </span>
          
          <a
            href={product.affiliateUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-shrink-0 bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-xl text-sm font-bold transition-colors"
          >
            Buy Now
          </a>
        </div>
      </div>
    </motion.div>
  );
}
