export type Category = 'pakistan' | 'global';
export type ProductCategory = 'Electronics' | 'Fashion' | 'Home & Kitchen' | 'Health & Beauty' | 'Sports' | 'Kids & Toys' | 'Other';

export interface Product {
  id: string;
  name: string;
  imageUrl: string;
  price: string;
  description: string;
  category: Category;
  productCategory?: ProductCategory;
  affiliateUrl: string;
  featured: boolean;
  trending: boolean;
  createdAt: number;
}
