import React from 'react';
import { motion } from 'motion/react';

export function PrivacyPolicy() {
  return (
    <div className="max-w-4xl mx-auto px-6 py-12">
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-3xl p-8 md:p-12 shadow-sm border border-slate-200"
      >
        <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-6 tracking-tight">Privacy Policy</h1>
        
        <div className="prose prose-slate max-w-none prose-headings:font-bold prose-a:text-blue-600">
          <p className="lead text-lg text-slate-600 mb-8">
            Welcome to Abbasi Mart. We respect your privacy and are committed to protecting your personal data. This privacy policy will inform you as to how we look after your personal data and tell you about your privacy rights.
          </p>

          <h2 className="text-xl font-bold text-slate-900 mt-8 mb-4">1. Information We Collect</h2>
          <p className="text-slate-600 mb-4">
            We may collect, use, store and transfer different kinds of personal data about you. However, as an affiliate platform, we mostly rely on non-personally identifiable information such as basic device info or analytics data to understand how our visitors interact with our site. We do not process payments or collect financial information directly.
          </p>

          <h2 className="text-xl font-bold text-slate-900 mt-8 mb-4">2. How We Use Your Information</h2>
          <p className="text-slate-600 mb-4">
            We use analytics to provide a better user experience and improve our product recommendations. When you click on an affiliate link and make a purchase, the external retailer (like Amazon or Daraz) may use cookies to track the purchase back to our site. This is standard practice in the affiliate industry and helps us maintain our platform.
          </p>

          <h2 className="text-xl font-bold text-slate-900 mt-8 mb-4">3. External Links and Third Parties</h2>
          <p className="text-slate-600 mb-4">
            Our website includes links to third-party websites, plug-ins, and applications. Clicking on those links or enabling those connections may allow third parties to collect or share data about you. We do not control these third-party websites and are not responsible for their privacy statements. When you leave our website, we encourage you to read the privacy policy of every website you visit.
          </p>

          <h2 className="text-xl font-bold text-slate-900 mt-8 mb-4">4. Contact Us</h2>
          <p className="text-slate-600 mb-4">
            If you have any questions about this privacy policy or our privacy practices, please contact us via email at: <strong>abbasimart011@gmail.com</strong>
          </p>
        </div>
      </motion.div>
    </div>
  );
}
