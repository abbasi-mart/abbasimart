import React, { useState, useMemo } from 'react';
import { Category, ProductCategory } from '../types';
import { useProducts } from '../context/ProductContext';
import { ProductCard } from '../components/ProductCard';
import { Search, MapPin, Globe, LayoutGrid, Filter } from 'lucide-react';
import { motion } from 'motion/react';

interface DealsProps {
  category: Category;
  title: string;
  description: string;
}

export function Deals({ category, title, description }: DealsProps) {
  const { products } = useProducts();
  const [search, setSearch] = useState('');
  const [selectedProductCat, setSelectedProductCat] = useState<ProductCategory | 'All'>('All');

  const PRODUCT_CATEGORIES: (ProductCategory | 'All')[] = ['All', 'Electronics', 'Fashion', 'Home & Kitchen', 'Health & Beauty', 'Sports', 'Kids & Toys', 'Other'];

  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const matchCategory = p.category === category;
      const matchSearch = p.name.toLowerCase().includes(search.toLowerCase()) || 
                          p.description.toLowerCase().includes(search.toLowerCase());
      const matchProductCat = selectedProductCat === 'All' || p.productCategory === selectedProductCat;
      return matchCategory && matchSearch && matchProductCat;
    });
  }, [products, category, search, selectedProductCat]);

  return (
    <div className="flex flex-col p-4 md:p-6 gap-6 bg-slate-50 w-full max-w-7xl mx-auto flex-grow">
      {/* Header */}
      <div className="bg-white border border-slate-200 rounded-3xl p-8 flex flex-col md:flex-row justify-between items-start md:items-end gap-6 shadow-sm">
        <div>
           <div className="inline-flex items-center gap-2 px-3 py-1 bg-slate-100 rounded-full text-slate-600 text-sm font-medium mb-4">
             {category === 'pakistan' ? 'Pakistan / Local' : 'Global / International'}
           </div>
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight flex items-center gap-3">
            {title}
          </h1>
          <p className="mt-2 text-slate-500 max-w-2xl text-sm">
            {description}
          </p>
        </div>

        {/* Search */}
        <div className="relative w-full md:w-80">
          <input
            type="text"
            className="block w-full pl-10 pr-3 py-3 bg-slate-100 border-none rounded-full text-sm focus:ring-2 focus:ring-blue-500 outline-none"
            placeholder="Search smart products..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <Search className="w-4 h-4 absolute left-4 top-3 text-slate-400" />
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex flex-nowrap overflow-x-auto gap-2 pb-2 scrollbar-hide -mx-4 px-4 md:mx-0 md:px-0">
        {PRODUCT_CATEGORIES.map(cat => (
          <button
            key={cat}
            onClick={() => setSelectedProductCat(cat)}
            className={`whitespace-nowrap px-4 py-2 rounded-full text-sm font-medium transition-colors ${
              selectedProductCat === cat 
                ? 'bg-slate-900 text-white shadow-sm' 
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Grid */}
      {filteredProducts.length > 0 ? (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4"
        >
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </motion.div>
      ) : (
        <div className="text-center py-24 bg-white rounded-3xl border border-slate-200 border-dashed">
          <LayoutGrid className="mx-auto h-12 w-12 text-slate-300 mb-4" />
          <h3 className="text-lg font-medium text-slate-900 mb-1">No deals found</h3>
          <p className="text-slate-500">
            {search ? "We couldn't find any deals matching your search." : "No deals are currently available in this category."}
          </p>
          {search && (
            <button 
              onClick={() => setSearch('')}
              className="mt-6 text-blue-600 font-medium hover:text-blue-700"
            >
              Clear search
            </button>
          )}
        </div>
      )}
    </div>
  );
}
