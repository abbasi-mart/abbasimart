import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingBag, Globe, MapPin, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';
import { useProducts } from '../context/ProductContext';
import { ProductCard } from '../components/ProductCard';

export function Home() {
  const { products } = useProducts();
  const featured = products.filter(p => p.featured).slice(0, 4);
  const trending = products.filter(p => p.trending && !p.featured).slice(0, 4);

  return (
    <div className="flex flex-col p-4 md:p-6 gap-4 bg-slate-50 w-full max-w-7xl mx-auto">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-600 to-blue-800 rounded-3xl p-8 md:p-12 flex flex-col justify-center text-white relative overflow-hidden">
        <div className="absolute right-[-20%] bottom-[-20%] w-64 md:w-96 h-64 md:h-96 bg-white/10 rounded-full blur-3xl" />
        
        <div className="relative z-10 max-w-3xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-block bg-white/20 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold mb-4"
          >
            Featured Destination
          </motion.div>
          
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-5xl font-extrabold leading-tight mb-2"
          >
            Abbasi Mart - Smart<br className="hidden md:block"/>Shopping Destination
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-blue-100 opacity-90 text-sm max-w-md mb-6"
          >
            Curated affiliate deals from Daraz, AliExpress, and global marketplaces. No hidden fees, just direct savings.
          </motion.p>
          
          <motion.div 
             initial={{ opacity: 0, y: 20 }}
             animate={{ opacity: 1, y: 0 }}
             transition={{ delay: 0.3 }}
             className="flex flex-col sm:flex-row gap-3"
          >
            <Link 
              to="/pakistan-deals" 
              className="bg-white text-blue-700 px-6 py-2.5 rounded-xl font-bold text-sm shadow-lg text-center"
            >
              Pakistan Deals
            </Link>
            <Link 
              to="/global-deals" 
              className="bg-blue-500/30 border border-white/30 backdrop-blur-md text-white px-6 py-2.5 rounded-xl font-bold text-sm text-center"
            >
              Global Deals
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Featured Section */}
      {featured.length > 0 && (
        <section className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm overflow-hidden flex flex-col">
          <div className="flex items-center gap-2 mb-6">
            <h3 className="text-xl font-bold text-slate-800">Featured Products</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {featured.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </section>
      )}

      {/* Trending Section */}
      {trending.length > 0 && (
        <section className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm overflow-hidden flex flex-col">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-slate-800">Trending Now</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {trending.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </section>
      )}
      
      {/* Category Links Bottom */}
      <section className="grid md:grid-cols-2 gap-4">
          <Link to="/pakistan-deals" className="group relative rounded-3xl overflow-hidden bg-slate-900 aspect-[2/1] md:aspect-auto md:h-64 border border-slate-200 shadow-sm flex flex-col justify-between p-6">
             <img 
               src="https://images.unsplash.com/photo-1542385315-bdbe4bfa95f8?w=1200&q=80" 
               alt="Pakistan Deals" 
               className="absolute inset-0 w-full h-full object-cover opacity-30 transition-transform duration-700 group-hover:scale-105"
             />
             <div className="relative z-10">
               <h3 className="text-2xl font-bold text-white mb-2 flex items-center gap-2">
                 Pakistan Deals
               </h3>
               <p className="text-slate-200 text-sm max-w-sm">Find the best local deals and fast shipping from top Pakistani stores.</p>
             </div>
             <div className="relative z-10 mt-auto flex items-start">
               <span className="inline-flex items-center text-sm gap-2 bg-white text-slate-900 px-4 py-2 rounded-xl font-bold">
                  Explore Local <ArrowRight className="w-4 h-4" />
               </span>
             </div>
          </Link>

          <Link to="/global-deals" className="group relative rounded-3xl overflow-hidden bg-slate-900 aspect-[2/1] md:aspect-auto md:h-64 border border-slate-200 shadow-sm flex flex-col justify-between p-6">
             <img 
               src="https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=1200&q=80" 
               alt="Global Deals" 
               className="absolute inset-0 w-full h-full object-cover opacity-30 transition-transform duration-700 group-hover:scale-105"
             />
             <div className="relative z-10">
               <h3 className="text-2xl font-bold text-white mb-2 flex items-center gap-2">
                 Global Deals
               </h3>
               <p className="text-slate-200 text-sm max-w-sm">Shop international products seamlessly. Gadgets, fashion, and more.</p>
             </div>
             <div className="relative z-10 mt-auto flex items-start">
               <span className="inline-flex items-center text-sm gap-2 bg-blue-600/30 border border-white/30 backdrop-blur-md text-white px-4 py-2 rounded-xl font-bold">
                  Explore Global <ArrowRight className="w-4 h-4" />
               </span>
             </div>
          </Link>
      </section>
    </div>
  );
}
