import React, { useState } from 'react';
import { useProducts } from '../context/ProductContext';
import { Product, Category } from '../types';
import { Plus, Edit2, Trash2, Save, X, Settings2, PackagePlus, Eye, LogOut } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export function Admin() {
  const { products, addProduct, updateProduct, deleteProduct } = useProducts();
  const [isAuthenticated, setIsAuthenticated] = useState(() => localStorage.getItem('isAdmin') === 'true');
  const [password, setPassword] = useState('');
  
  const [isEditing, setIsEditing] = useState<string | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [formData, setFormData] = useState<Partial<Product>>({});

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === 'samad2026') {
      localStorage.setItem('isAdmin', 'true');
      setIsAuthenticated(true);
    } else {
      alert('Invalid password.');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('isAdmin');
    setIsAuthenticated(false);
  };

  const startEdit = (product: Product) => {
    setFormData(product);
    setIsEditing(product.id);
    setIsCreating(false);
  };

  const startCreate = () => {
    setFormData({
      name: '',
      imageUrl: '',
      price: '',
      description: '',
      category: 'pakistan',
      affiliateUrl: '',
      featured: false,
      trending: false,
    });
    setIsCreating(true);
    setIsEditing(null);
  };

  const cancelEdit = () => {
    setIsEditing(null);
    setIsCreating(false);
    setFormData({});
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isCreating) {
      addProduct(formData as Omit<Product, 'id' | 'createdAt'>);
    } else if (isEditing) {
      updateProduct(isEditing, formData);
    }
    cancelEdit();
  };

  if (!isAuthenticated) {
    return (
      <div className="flex-grow flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white p-8 rounded-3xl shadow-xl w-full max-w-md border border-slate-100"
        >
          <div className="w-12 h-12 bg-slate-900 rounded-xl flex items-center justify-center mb-6 mx-auto">
             <Settings2 className="w-6 h-6 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-center text-slate-900 mb-6">Admin Access</h2>
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Password</label>
              <input
                type="password"
                required
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-slate-900 focus:border-slate-900 transition-colors"
                value={password}
                placeholder="Enter password"
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            <button
              type="submit"
              className="w-full bg-slate-900 hover:bg-slate-800 text-white font-semibold py-3 rounded-xl transition-colors"
            >
              Login
            </button>
          </form>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="flex flex-col p-4 md:p-6 gap-6 bg-slate-50 w-full max-w-7xl mx-auto flex-grow">
      <div className="bg-slate-900 rounded-3xl p-6 md:p-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-6 shadow-sm">
        <div>
           <h1 className="text-3xl font-bold text-white mb-2">Owner's Dashboard</h1>
           <p className="text-slate-400 text-sm">Manage your affiliate catalog and links efficiently.</p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={startCreate}
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-xl font-bold transition-colors shadow-lg"
          >
            <PackagePlus className="w-5 h-5" />
            ADD PRODUCT
          </button>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white px-5 py-2.5 rounded-xl font-bold transition-colors border border-white/5"
          >
            <LogOut className="w-4 h-4" />
            LOGOUT
          </button>
        </div>
      </div>

      <AnimatePresence>
        {(isCreating || isEditing) && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden mb-8"
          >
            <form onSubmit={handleSubmit} className="bg-white p-6 md:p-8 rounded-2xl shadow-sm border border-slate-200">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold text-slate-900">
                  {isCreating ? 'Add New Product' : 'Edit Product'}
                </h2>
                <button type="button" onClick={cancelEdit} className="p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Product Name</label>
                  <input
                    type="text" required
                    className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    value={formData.name || ''}
                    onChange={e => setFormData({...formData, name: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Price</label>
                  <div className="flex gap-2">
                    <select
                      className="w-24 p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white shrink-0"
                      value={formData.price?.includes('$') ? '$' : 'Rs. '}
                      onChange={e => {
                         const val = formData.price || '';
                         const numVal = val.replace(/^(\$|Rs\.\s?)/, '');
                         setFormData({...formData, price: e.target.value + numVal});
                      }}
                    >
                      <option value="Rs. ">PKR</option>
                      <option value="$">USD</option>
                    </select>
                    <input
                      type="text" required placeholder="e.g. 1000"
                      className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                      value={formData.price?.replace(/^(\$|Rs\.\s?)/, '') || ''}
                      onChange={e => {
                         const currency = formData.price?.includes('$') ? '$' : 'Rs. ';
                         setFormData({...formData, price: currency + e.target.value});
                      }}
                    />
                  </div>
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-slate-700 mb-1">Product Image</label>
                  <label className="cursor-pointer bg-blue-50 hover:bg-blue-100 border-2 border-dashed border-blue-200 text-blue-700 px-4 py-8 rounded-xl font-medium transition-colors flex flex-col items-center justify-center text-center">
                    <span className="text-2xl mb-2">📸</span>
                    {formData.imageUrl ? 'Change Picture' : 'Click to Upload Picture'}
                    <input 
                      type="file" 
                      accept="image/*" 
                      className="hidden" 
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onloadend = () => {
                            setFormData({...formData, imageUrl: reader.result as string});
                          };
                          reader.readAsDataURL(file);
                        }
                      }}
                    />
                  </label>
                  {formData.imageUrl && (
                    <div className="mt-3 w-32 h-32 rounded-lg overflow-hidden border border-slate-200 bg-slate-50">
                      <img src={formData.imageUrl} alt="Preview" className="w-full h-full object-cover relative z-10" />
                    </div>
                  )}
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-slate-700 mb-1">Affiliate URL (External)</label>
                  <input
                    type="url" required
                    className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    value={formData.affiliateUrl || ''}
                    onChange={e => setFormData({...formData, affiliateUrl: e.target.value})}
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-slate-700 mb-1">Description (Short)</label>
                  <textarea
                    required rows={3}
                    className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    value={formData.description || ''}
                    onChange={e => setFormData({...formData, description: e.target.value})}
                  ></textarea>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Region</label>
                  <select
                    className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white"
                    value={formData.category || 'pakistan'}
                    onChange={e => setFormData({...formData, category: e.target.value as Category})}
                  >
                    <option value="pakistan">Pakistan Deals</option>
                    <option value="global">Global Deals</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Product Category</label>
                  <select
                    className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 bg-white"
                    value={formData.productCategory || 'Other'}
                    onChange={e => setFormData({...formData, productCategory: e.target.value as any})}
                  >
                    <option value="Electronics">Electronics</option>
                    <option value="Fashion">Fashion</option>
                    <option value="Home & Kitchen">Home & Kitchen</option>
                    <option value="Health & Beauty">Health & Beauty</option>
                    <option value="Sports">Sports</option>
                    <option value="Kids & Toys">Kids & Toys</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div className="flex items-center gap-6 pt-6">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      className="w-5 h-5 rounded text-blue-600 focus:ring-blue-500"
                      checked={formData.featured || false}
                      onChange={e => setFormData({...formData, featured: e.target.checked})}
                    />
                    <span className="text-sm font-medium text-slate-700">Featured</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      className="w-5 h-5 rounded text-blue-600 focus:ring-blue-500"
                      checked={formData.trending || false}
                      onChange={e => setFormData({...formData, trending: e.target.checked})}
                    />
                    <span className="text-sm font-medium text-slate-700">Trending</span>
                  </label>
                </div>
              </div>

              <div className="mt-8 flex justify-end gap-3 pt-6 border-t border-slate-100">
                <button
                  type="button"
                  onClick={cancelEdit}
                  className="px-6 py-2.5 border border-slate-300 text-slate-700 rounded-lg font-medium hover:bg-slate-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-slate-900 text-white rounded-lg font-medium hover:bg-slate-800 transition-colors flex items-center gap-2"
                >
                  <Save className="w-4 h-4" />
                  Save Product
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Products Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-600">
            <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
              <tr>
                <th className="px-6 py-4">Product</th>
                <th className="px-6 py-4 hidden md:table-cell">Region / Category</th>
                <th className="px-6 py-4">Price</th>
                <th className="px-6 py-4 hidden lg:table-cell">Badges</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {products.map(product => (
                <tr key={product.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-md bg-slate-100 flex-shrink-0 overflow-hidden">
                         <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover" />
                      </div>
                      <div className="font-medium text-slate-900 line-clamp-2 max-w-[200px]">{product.name}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 hidden md:table-cell">
                    <div className="flex flex-col gap-1 items-start">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        product.category === 'pakistan' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'
                      }`}>
                        {product.category === 'pakistan' ? 'Pakistan' : 'Global'}
                      </span>
                      {product.productCategory && (
                        <span className="text-xs text-slate-500 font-medium">
                          {product.productCategory}
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 font-medium text-slate-900">
                    {product.price}
                  </td>
                  <td className="px-6 py-4 hidden lg:table-cell">
                    <div className="flex gap-2 text-xs">
                      {product.featured && <span className="text-blue-600 font-medium">Featured</span>}
                      {product.trending && <span className="text-orange-500 font-medium ml-1">Trending</span>}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                       <a 
                         href={product.affiliateUrl} target="_blank" rel="noopener noreferrer"
                         className="p-2 text-slate-400 hover:text-blue-600 rounded-md hover:bg-blue-50 transition-colors"
                         title="View Affiliate Link"
                       >
                         <Eye className="w-4 h-4" />
                       </a>
                      <button
                        onClick={() => startEdit(product)}
                        className="p-2 text-slate-400 hover:text-slate-900 rounded-md hover:bg-slate-100 transition-colors"
                        title="Edit"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => {
                          if (window.confirm('Are you sure you want to delete this product?')) {
                            deleteProduct(product.id);
                          }
                        }}
                        className="p-2 text-slate-400 hover:text-red-600 rounded-md hover:bg-red-50 transition-colors"
                        title="Delete"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {products.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-6 py-8 text-center text-slate-500">
                    No products added yet. Click "Add Product" to get started.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
