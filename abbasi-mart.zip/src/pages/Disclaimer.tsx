import React from 'react';
import { motion } from 'motion/react';

export function Disclaimer() {
  return (
    <div className="max-w-4xl mx-auto px-6 py-12">
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-3xl p-8 md:p-12 shadow-sm border border-slate-200"
      >
        <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-6 tracking-tight">Affiliate Disclaimer</h1>
        
        <div className="prose prose-slate max-w-none prose-headings:font-bold prose-p:text-slate-600 prose-p:leading-relaxed">
          <p className="lead text-lg mb-8 font-medium">
            At Abbasi Mart, transparency is one of our core values. We want to be completely open about how we operate our platform and business.
          </p>

          <h2 className="text-xl font-bold text-slate-900 mt-8 mb-4">Nature of Our Business</h2>
          <p className="mb-4">
            Abbasi Mart is an independent affiliate marketing platform and directory. We operate primarily by identifying, curating, and sharing high-quality products, daily deals, and discounts available across various external e-commerce sites (such as Daraz, Amazon, and others). 
          </p>

          <h2 className="text-xl font-bold text-slate-900 mt-8 mb-4">No Direct Sales or Liability</h2>
          <p className="mb-4">
            Please be advised that <strong>we do not sell any products directly</strong>. We do not manufacture, stock, ship, or handle customer service for any of the physical or digital items listed on this website. 
          </p>
          <p className="mb-4">
            Because we simply act as a referrer, <strong>Abbasi Mart holds no liability or responsibility for any products purchased through the links provided on our site</strong>. Any issues related to product quality, shipping delays, refunds, warranties, or customer service must be directed entirely to the original vendor or marketplace where the purchase was completed.
          </p>

          <h2 className="text-xl font-bold text-slate-900 mt-8 mb-4">Affiliate Relationships</h2>
          <p className="mb-4">
            When you click on links to various merchants on this site and make a purchase, this may result in a small commission being credited to Abbasi Mart. This comes at absolutely no additional cost to you, and it helps us maintain the server costs and operation of this platform. Our participation in these affiliate programs does not influence the products we choose to list—we aim to provide the best selections objectively.
          </p>

          <h2 className="text-xl font-bold text-slate-900 mt-8 mb-4">Product Accuracy</h2>
          <p className="mb-4">
            While we strive to ensure that product details, prices, and availability are accurate at the time of publication, e-commerce marketplaces frequently adjust their pricing and inventory. We cannot guarantee that any specific deal or price listed on Abbasi Mart will remain valid indefinitely or exactly as described when you click through to the seller's website.
          </p>

          <p className="mt-12 text-sm italic text-slate-500">
            By using this website, you agree that you understand our strictly informational and affiliate nature, and agree to hold Abbasi Mart harmless from any disputes arising from your interactions with third-party vendors.
          </p>
        </div>
      </motion.div>
    </div>
  );
}
