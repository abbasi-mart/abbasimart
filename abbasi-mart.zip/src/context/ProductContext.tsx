import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product } from '../types';

const defaultProducts: Product[] = [
  {
    id: '1',
    name: 'Wireless Noise Cancelling Headphones',
    imageUrl: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&q=80',
    price: '$199.99',
    description: 'Premium wireless headphones with industry-leading noise cancellation and high-res audio quality.',
    category: 'global',
    productCategory: 'Electronics',
    affiliateUrl: 'https://www.aliexpress.com',
    featured: true,
    trending: true,
    createdAt: Date.now(),
  },
  {
    id: '2',
    name: 'Traditional Lawn Suit Collection',
    imageUrl: 'https://images.unsplash.com/photo-1583391733958-6c5eeaa70d6a?w=800&q=80',
    price: 'Rs. 4,500',
    description: 'Unstitched 3-piece premium lawn suit with beautiful embroidery patterns, perfect for summer.',
    category: 'pakistan',
    productCategory: 'Fashion',
    affiliateUrl: 'https://www.daraz.pk',
    featured: true,
    trending: false,
    createdAt: Date.now() - 1000,
  },
  {
    id: '3',
    name: 'Smart Fitness Tracker Pro',
    imageUrl: 'https://images.unsplash.com/photo-1575311373937-040b8e1fd5b0?w=800&q=80',
    price: '$45.00',
    description: 'Advanced fitness band with heart rate monitor, sleep tracking, and 14-day battery life.',
    category: 'global',
    productCategory: 'Electronics',
    affiliateUrl: 'https://www.aliexpress.com',
    featured: false,
    trending: true,
    createdAt: Date.now() - 2000,
  },
  {
    id: '4',
    name: 'Handcrafted Blue Pottery Plate',
    imageUrl: 'https://images.unsplash.com/photo-1610738466185-3e28aa41cd5e?w=800&q=80',
    price: 'Rs. 1,200',
    description: 'Authentic Multani blue pottery, expertly handcrafted and painted by local artisans.',
    category: 'pakistan',
    productCategory: 'Home & Kitchen',
    affiliateUrl: 'https://www.daraz.pk',
    featured: false,
    trending: true,
    createdAt: Date.now() - 3000,
  }
];

interface ProductContextType {
  products: Product[];
  addProduct: (product: Omit<Product, 'id' | 'createdAt'>) => void;
  updateProduct: (id: string, product: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
}

const ProductContext = createContext<ProductContextType | undefined>(undefined);

export function ProductProvider({ children }: { children: React.ReactNode }) {
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('abbasi_mart_products');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return defaultProducts;
      }
    }
    return defaultProducts;
  });

  useEffect(() => {
    localStorage.setItem('abbasi_mart_products', JSON.stringify(products));
  }, [products]);

  const addProduct = (product: Omit<Product, 'id' | 'createdAt'>) => {
    const newProduct: Product = {
      ...product,
      id: crypto.randomUUID(),
      createdAt: Date.now(),
    };
    setProducts((prev) => [newProduct, ...prev]);
  };

  const updateProduct = (id: string, updates: Partial<Product>) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...updates } : p))
    );
  };

  const deleteProduct = (id: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== id));
  };

  return (
    <ProductContext.Provider value={{ products, addProduct, updateProduct, deleteProduct }}>
      {children}
    </ProductContext.Provider>
  );
}

export function useProducts() {
  const context = useContext(ProductContext);
  if (context === undefined) {
    throw new Error('useProducts must be used within a ProductProvider');
  }
  return context;
}
