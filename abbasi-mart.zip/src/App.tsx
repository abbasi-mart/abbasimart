import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { ProductProvider } from './context/ProductContext';
import { Layout } from './components/Layout';
import { Home } from './pages/Home';
import { Deals } from './pages/Deals';
import { Admin } from './pages/Admin';
import { PrivacyPolicy } from './pages/PrivacyPolicy';
import { Disclaimer } from './pages/Disclaimer';

export default function App() {
  return (
    <ProductProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<Home />} />
            <Route 
              path="pakistan-deals" 
              element={
                <Deals 
                  category="pakistan" 
                  title="Pakistan Deals" 
                  description="Shop top trending local products from reliable Pakistani platforms like Daraz." 
                />
              } 
            />
            <Route 
              path="global-deals" 
              element={
                <Deals 
                  category="global" 
                  title="Global Deals" 
                  description="Explore premium international gadgets, fashion, and lifestyle items." 
                />
              } 
            />
            <Route path="privacy-policy" element={<PrivacyPolicy />} />
            <Route path="disclaimer" element={<Disclaimer />} />
            <Route path="admin" element={<Admin />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </ProductProvider>
  );
}
